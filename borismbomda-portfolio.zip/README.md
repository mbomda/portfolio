# Boris Mbomda — AI Automation Portfolio

Portfolio professionnel orienté AI Automation, n8n, intégration d'API et Digital Operations.

## Fichiers

- `index.html` : portfolio public
- `automation/prompt-demo.md` : démonstration anonymisée du prompt

## Workflow

Excel + prompt → extraction → nettoyage → prompts dynamiques → DeepSeek Reasoner → nettoyage → regroupement → Markdown / DOCX.

## GitHub Pages

Le dépôt doit être nommé `borismbomda.github.io`.

Ne publiez jamais de clé API, token, mot de passe, identifiant privé ou donnée client.
