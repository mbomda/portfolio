# Prompt d'automatisation — démonstration publique

Cette version est volontairement anonymisée afin de présenter la logique du workflow sans publier d'instructions professionnelles confidentielles.

Entrée : {{TÂCHE_EXCEL}}

Objectif :
Traiter automatiquement la tâche selon les règles définies dans le squelette de prompt.

Étapes :
1. Récupérer la tâche.
2. Nettoyer et préparer les données.
3. Construire le prompt dynamique.
4. Envoyer la demande au modèle IA.
5. Contrôler et nettoyer la sortie.
6. Regrouper les résultats.
7. Préparer l'export.

Sortie :
Contenu structuré, contrôlé et prêt pour l'export.

Technologies :
n8n · DeepSeek API · Excel · Prompt Engineering · JavaScript · Pandoc
